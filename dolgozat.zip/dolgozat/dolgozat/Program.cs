﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;




namespace dolgozat
{
    class Program
    {
       
        static void Main(string[] args)
        {
            //3, 5 feladat nem kell!!!!
            
            StreamReader sr = new StreamReader("nobel.csv");

            while (!sr.EndOfStream)
            {
                
            }
            
            List<Nobel> adatok = new List<Nobel>();


            Console.WriteLine($"4. feladat: {adatok.Where(x => x.Evszam == 2017)}");
            Console.WriteLine($"6. feladat: {adatok.Where(x => x.Vezeteknev == "Cuire", x.Evszam)}");
            Console.WriteLine($"7. feladat: {adatok.Select(x => x.Tipus).Count()} db");

            sr.Close(); 
        }
    }
}
